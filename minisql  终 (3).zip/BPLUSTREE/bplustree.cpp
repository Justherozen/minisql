//������Ұ���¶�
#include "bplustree.h"

BPlusTree::BPlusTree(const std::string index_name, int KeyTypeIndex, char(&mRecordTypeInfo)[RecordColumnCount * 4], char(&mRecordColumnName)[RecordColumnCount * ColumnNameLength], char(&mIndexName)[RecordColumnCount * ColumnNameLength], bool(&mUniqueInfo)[RecordColumnCount], int PrimaryKey, bool(&mIsUniqueBuild)[RecordColumnCount]):IndexName(index_name)
{
	BUFFER &buffer = GetGlobalFileBuffer();
	auto MemFileptr = buffer[IndexName.c_str()];
	// ��������ļ��������򴴽�
	if (!MemFileptr)
	{
		buffer.CreateFile(IndexName.c_str());
		MemFileptr = buffer[IndexName.c_str()];
		// ��ʼ�������ļ���root�ڵ�
		BPlusTNode root_node;
		assert(sizeof(BPlusTNode)<(FILE_PAGESIZE-sizeof(PAGEHEAD)));
		root_node.node_type = BTNodeType::ROOT;
		root_node.key_totalnum = 0;
		root_node.next = FileAddr{ 0,0 };
		FileAddr root_node_record= buffer[IndexName.c_str()]->AddRecord(&root_node, sizeof(root_node));
		// ��ʼ��indexhead
		IndexHead.root = root_node_record;
		IndexHead.MostLeftNode = root_node_record;
		IndexHead.KeyTypeIndex = KeyTypeIndex;
		IndexHead.PrimaryKey = PrimaryKey;
		memcpy(IndexHead.RecordTypeInfo, mRecordTypeInfo, RecordColumnCount*4);
		memcpy(IndexHead.IsUniqueBuild, mIsUniqueBuild, RecordColumnCount);
		memcpy(IndexHead.UniqueInfo, mUniqueInfo, RecordColumnCount);
		memcpy(IndexHead.RecordColumnName, mRecordColumnName, RecordColumnCount * ColumnNameLength);
		memcpy(IndexHead.IndexName, mIndexName, RecordColumnCount * ColumnNameLength);
		// �����ĵ�ַд���ļ�ͷ��Ԥ���ռ���
		memcpy(buffer[IndexName.c_str()]->GetFileFirstPage()->GetFileCond()->reserve, &IndexHead, sizeof(IndexHead));
	}
	File_ID = MemFileptr->fileId;
}

BPlusTree::BPlusTree(std::string idx_name)
{
	IndexName = idx_name;
	File_ID = GetGlobalFileBuffer()[idx_name.c_str()]->fileId;
}


// ��һ��������� x, ����ؼ��� k, k�����ݵ�ַΪ k_addr
void BPlusTree::InsertNotFull(FileAddr x, KeyAttr k, FileAddr k_addr)
{
	auto nodex = FileAddrToMemPtr(x);
	int i = nodex->key_totalnum - 1;

	
	if (nodex->node_type == BTNodeType::INTERNAL)//���ڲ��ڵ� �жϲ��λ�����Ƿ����
	{
		while (i >= 0&&k< nodex->key[i])i--;
		// ��������ֵ���ڽڵ��ֵ��С
		if (i < 0) {
			i = 0;
			nodex->key[i] = k;
		}
		assert(i >= 0);
		FileAddr childaddr = nodex->children[i];
		auto ptrchildaddr = FileAddrToMemPtr(childaddr);
		if (ptrchildaddr->key_totalnum == MaxKeyNum)
		{
			NodeSplit(x, i, childaddr);
			if (k >= nodex->key[i + 1])
				i += 1;
		}
		InsertNotFull(nodex->children[i], k, k_addr);
	}
	else// ����ý����Ҷ�ӽ�㣬ֱ�Ӳ���
	{
		while (i >= 0 && k < nodex->key[i])
		{
			nodex->children[i + 1] = nodex->children[i];
			nodex->key[i + 1] = nodex->key[i];
			i--;
		}
		nodex->children[i + 1] = k_addr;
		nodex->key[i + 1] = k;
		nodex->key_totalnum += 1;
	}
}

// ��x�±�Ϊi�ĺ�����������
void BPlusTree::NodeSplit(FileAddr x, int i, FileAddr c)
{
	auto pMemPageX = GetGlobalPageManager()->GetMemAddr(File_ID, x.filePageID);
	auto pMemPageY = GetGlobalPageManager()->GetMemAddr(File_ID, c.filePageID);
	pMemPageX->isModified = true;
	pMemPageY->isModified = true;

	BPlusTNode* nodex = FileAddrToMemPtr(x);
	BPlusTNode* nodei = FileAddrToMemPtr(c);
	BPlusTNode z;         // ���ѳ������½��
	FileAddr z_fd;    // �½����ļ��ڵ�ַ

	z.node_type = nodei->node_type;
	z.key_totalnum = MaxKeyNum / 2;

	// ��y����һ������ת�Ƶ��½��
	for (int k = MaxKeyNum / 2; k < MaxKeyNum; k++)
	{
		z.key[k - MaxKeyNum / 2] = nodei->key[k];
		z.children[k - MaxKeyNum / 2] = nodei->children[k];
	}
	nodei->key_totalnum = MaxKeyNum / 2;

	// ��y�ĸ��ڵ�x�������´������ӽ�� z
	int j;
	for (j = nodex->key_totalnum - 1; j > i; j--)
	{
		nodex->key[j + 1] = nodex->key[j];
		nodex->children[j + 1] = nodex->children[j];
	}

	j++; // after j++, j should be i+1;
	nodex->key[j] = z.key[0];

	if (nodei->node_type == BTNodeType::LEAF)
	{
		z.next = nodei->next;
		z_fd = GetGlobalFileBuffer()[IndexName.c_str()]->AddRecord(&z, sizeof(z));
		nodei->next = z_fd;
	}
	else
		z_fd = GetGlobalFileBuffer()[IndexName.c_str()]->AddRecord(&z, sizeof(z));

	nodex->children[j] = z_fd;
	nodex->key_totalnum++;
}

FileAddr BPlusTree::Search(KeyAttr search_key)
{
	auto pMemPage = GetGlobalPageManager()->GetMemAddr(File_ID, 0);
	auto pfilefd = (FileAddr*)pMemPage->GetFileCond()->reserve;  // �ҵ������ĵ�ַ
	return Search(search_key, *pfilefd);
}

FileAddr BPlusTree::Search(KeyAttr search_key, FileAddr node_fd)
{
	BPlusTNode* pNode = FileAddrToMemPtr(node_fd);

	if (pNode->node_type == BTNodeType::LEAF || pNode->node_type == BTNodeType::ROOT)
	{
		return SearchKey_Leaf(search_key, node_fd);
	}
	else
	{
		return SearchKey_Internal(search_key, node_fd);
	}
}

bool BPlusTree::Insert(KeyAttr k, FileAddr k_addr)
{
	// ����ùؼ����Ѿ����������ʧ��
	try
	{
		auto key_fd = Search(k);
		if (key_fd != FileAddr{ 0,0 })
			throw SQLError::KEY_INSERT_ERROR();
	}
	catch (const SQLError::BaseError & error)
	{
		SQLError::DispatchError(error);
		std::cout << std::endl;
		return false;
	}

	// �õ�������fd
	FileAddr root_fd = *(FileAddr*)GetGlobalFileBuffer()[IndexName.c_str()]->GetFileFirstPage()->GetFileCond()->reserve;
	auto proot = FileAddrToMemPtr(root_fd);
	if (proot->key_totalnum == MaxKeyNum)
	{
		// �����µĽ�� s ,��Ϊ�����
		BPlusTNode s;
		s.node_type = BTNodeType::INTERNAL;  // ֻ�г�ʼ����ʹ�� BTNodeType::ROOT
		s.key_totalnum = 1;
		s.key[0] = proot->key[0];
		s.children[0] = root_fd;
		FileAddr s_fd = GetGlobalFileBuffer()[IndexName.c_str()]->AddRecord(&s, sizeof(BPlusTNode));

		// ���µĸ��ڵ��ļ���ַд��
		*(FileAddr*)GetGlobalFileBuffer()[IndexName.c_str()]->GetFileFirstPage()->GetFileCond()->reserve = s_fd;
		GetGlobalFileBuffer()[IndexName.c_str()]->GetFileFirstPage()->isModified = true;

		//���ɵĸ��������ΪҶ�ӽ��
		auto pOldRoot = FileAddrToMemPtr(root_fd);
		if (pOldRoot->node_type == BTNodeType::ROOT)
			pOldRoot->node_type = BTNodeType::LEAF;

		// �ȷ����ٲ���
		NodeSplit(s_fd, 0, s.children[0]);
		InsertNotFull(s_fd, k, k_addr);
	}
	else
	{
		InsertNotFull(root_fd, k, k_addr);
	}
	return true;
}

// ���¹ؼ���
FileAddr BPlusTree::UpdateKey(KeyAttr a, KeyAttr k)
{
	// ��������ɾ���ɵĹؼ���
	auto data_fd = Delete(a);  // ����ؼ��ֶ�Ӧ�ļ�¼��ַ
	//�����µĹؼ���
	Insert(k, data_fd);
	return data_fd;
}

FileAddr BPlusTree::Delete(KeyAttr key)
{
	auto search_res = Search(key);
	if (search_res.offSet == 0)
		return FileAddr{ 0,0 };

	// �õ�������fd
	FileAddr root_fd = *(FileAddr*)GetGlobalFileBuffer()[IndexName.c_str()]->GetFileFirstPage()->GetFileCond()->reserve;
	auto proot = FileAddrToMemPtr(root_fd);


	// ���ڵ�ΪROOT ���� LEAF ֱ��ɾ��
	if (proot->node_type == BTNodeType::ROOT || proot->node_type == BTNodeType::LEAF)
	{
		// ֱ��ɾ��
		int j = proot->key_totalnum - 1;
		while (proot->key[j] != key)j--;
		assert(j >= 0);
		FileAddr fd_res = proot->children[j];
		for (j++; j < proot->key_totalnum; j++)
		{
			proot->key[j - 1] = proot->key[j];
			proot->children[j - 1] = proot->children[j];
		}
		proot->key_totalnum--;
		return fd_res;
	}

	int i = proot->key_totalnum - 1;
	while (proot->key[i] > key)i--;
	assert(i >= 0);
	auto fd_delete = DeleteKey_Internal(root_fd, i, key);


	if (proot->key_totalnum == 1)
	{
		// ���µĸ��ڵ��ļ���ַд��
		*(FileAddr*)GetGlobalFileBuffer()[IndexName.c_str()]->GetFileFirstPage()->GetFileCond()->reserve = proot->children[0];
		GetGlobalFileBuffer()[IndexName.c_str()]->GetFileFirstPage()->isModified = true;

		GetGlobalFileBuffer()[IndexName.c_str()]->DeleteRecord(&root_fd, sizeof(BPlusTNode));
	}

	return fd_delete;
}



FileAddr BPlusTree::DeleteKey_Internal(FileAddr x, int i, KeyAttr key)//i-th children of the x file 
{
	BPlusTNode* nodex = FileAddrToMemPtr(x);
	BPlusTNode* childnode = FileAddrToMemPtr(nodex->children[i]);
	FileAddr fd_res;
	if (childnode->node_type == BTNodeType::LEAF)
	{
		fd_res = DeleteKey_Leaf(x, i, key);
	}
	else
	{
		int j = childnode->key_totalnum - 1;
		while (childnode->key[j] > key)j--;
		assert(j >= 0);
		fd_res = DeleteKey_Internal(nodex->children[i], j, key);
	}
	if (childnode->key_totalnum >= MaxKeyNum / 2)
		return fd_res;
	// ���ɾ����Ĺؼ��ָ���������B+���Ĺ涨�����ֵܽ�����key
	// ������ֵܴ������и���ؼ���
	if ((i <= nodex->key_totalnum - 2) && (FileAddrToMemPtr(nodex->children[i + 1])->key_totalnum > MaxKeyNum / 2))
	{
		auto RBrother = FileAddrToMemPtr(nodex->children[i + 1]);
		// �����Ĺؼ���
		auto key_bro = RBrother->key[0];
		auto fd_bro = RBrother->children[0];


		// �������ֵܵ��������
		nodex->key[i + 1] = RBrother->key[1];
		// �������ֵܽ��
		for (int j = 1; j <= RBrother->key_totalnum - 1; j++)
		{
			RBrother->key[j - 1] = RBrother->key[j];
			RBrother->children[j - 1] = RBrother->children[j];
		}
		RBrother->key_totalnum -= 1;

		// ���±�Ҷ�ӽ��
		childnode->key[childnode->key_totalnum] = key_bro;
		childnode->children[childnode->key_totalnum] = fd_bro;
		childnode->key_totalnum += 1;

		return fd_res;
	}
	// ������ֵܴ������и���ؼ���
	if (i > 0 && FileAddrToMemPtr(nodex->children[i - 1])->key_totalnum > MaxKeyNum / 2)
	{
		auto LBrother = FileAddrToMemPtr(nodex->children[i - 1]);
		// �����Ĺؼ���
		auto key_bro = LBrother->key[LBrother->key_totalnum - 1];
		auto fd_bro = LBrother->children[LBrother->key_totalnum - 1];

		// �������ֵܽ��
		LBrother->key_totalnum -=1;

		// ���±����
		nodex->key[i] = key_bro;
		for (int j = childnode->key_totalnum - 1; j >= 0; j--)
		{
			childnode->key[j + 1] = childnode->key[j];
			childnode->children[j + 1] = childnode->children[j];
		}
		childnode->key[0] = key_bro;
		childnode->children[0] = fd_bro;

		childnode->key_totalnum += 1;

		return fd_res;
	}

	// ���ֵܽ����û�и����key,��ǰ�����ֵܽ��ϲ���һ���µ�Ҷ�ӽ�㣬��ɾ��������е�key

	// �����ֵܴ��ڽ���ϲ�
	if (i < nodex->key_totalnum - 1)
	{
		auto RBrother = FileAddrToMemPtr(nodex->children[i + 1]);
		for (int j = 0; j < RBrother->key_totalnum; j++)
		{
			childnode->key[childnode->key_totalnum] = RBrother->key[j];
			childnode->children[childnode->key_totalnum] = RBrother->children[j];
			childnode->key_totalnum++;
		}

		// ����next
		childnode->next = RBrother->next;
		// ɾ���ҽ��
		GetGlobalFileBuffer()[IndexName.c_str()]->DeleteRecord(&nodex->children[i + 1], sizeof(BPlusTNode));
		// ���¸��ڵ�����
		for (int j = i + 2; j < nodex->key_totalnum; j++)
		{
			nodex->key[j - 1] = nodex->key[j];
			nodex->children[j - 1] = nodex->children[j];
		}
		nodex->key_totalnum--;
	}
	else
	{// ������ϲ�
		auto LBrother = FileAddrToMemPtr(nodex->children[i - 1]);
		for (int j = 0; j < childnode->key_totalnum; j++)
		{
			LBrother->key[LBrother->key_totalnum] = childnode->key[j];
			LBrother->children[LBrother->key_totalnum] = childnode->children[j];
			LBrother->key_totalnum++;
		}

		// ����next
		LBrother->next = childnode->next;

		// ɾ�������
		GetGlobalFileBuffer()[IndexName.c_str()]->DeleteRecord(&nodex->children[i], sizeof(BPlusTNode));
		// ���¸��ڵ�����
		for (int j = i + 1; j < nodex->key_totalnum; j++)
		{
			nodex->key[j - 1] = nodex->key[j];
			nodex->children[j - 1] = nodex->children[j];
		}
		nodex->key_totalnum--;
	}
	return fd_res;
}

// �����ɾ���Ĺؼ����Ѿ�����
FileAddr BPlusTree::DeleteKey_Leaf(FileAddr x, int i, KeyAttr key)
{
	auto nodex = FileAddrToMemPtr(x);
	auto nodei = FileAddrToMemPtr(nodex->children[i]);
	FileAddr fd_res;
	int j = nodei->key_totalnum - 1;
	while (nodei->key[j] != key)j--;
	assert(j >= 0);
	fd_res = nodei->children[j];
	// ɾ��Ҷ�ڵ�����С�Ĺؼ��֣����¸��ڵ�
	if (j == 0)
	{
		nodex->key[i] = nodei->key[j+1];
	}

	j++;
	while (j <= nodei->key_totalnum - 1)
	{
		nodei->children[j - 1] = nodei->children[j];
		nodei->key[j - 1] = nodei->key[j];
		j++;
	}
	nodei->key_totalnum -= 1;
	return fd_res;
}


void BPlusTree::PrintAllLeafNode()
{
	auto phead = (IndexHeadNode*)GetGlobalFileBuffer()[IndexName.c_str()]->GetFileFirstPage()->GetFileCond()->reserve;
	auto pRoot = FileAddrToMemPtr(phead->root);
	if (pRoot->key_totalnum <= 0)
	{
		std::cout << "��¼Ϊ��" << std::endl;
		return;
	}

	auto pNode = FileAddrToMemPtr(phead->MostLeftNode);
	
	
	static int n = 0;
	while (pNode->next.offSet != 0)
	{
		for (int i = 0; i < pNode->key_totalnum; i++)
		{
			n++;
			std::cout << pNode->key[i];
		}
			
		pNode = FileAddrToMemPtr(pNode->next);
	}
	for (int i = 0; i < pNode->key_totalnum; i++)
	{
		n++;
		std::cout << pNode->key[i];
	}
	std::cout << std::endl << n << std::endl;
}

IndexHeadNode * BPlusTree::GetIdxHeadNodePtr()
{
	auto phead = (IndexHeadNode*)GetGlobalFileBuffer()[IndexName.c_str()]->GetFileFirstPage()->GetFileCond()->reserve;
	return phead;
}

FileAddr BPlusTree::SearchKey_Internal(KeyAttr search_key, FileAddr node_fd)
{
	FileAddr fd_res{0,0};

	BPlusTNode* pNode = FileAddrToMemPtr(node_fd);
	for (int i = pNode->key_totalnum - 1; i >= 0; i--)
	{
		if (pNode->key[i] <= search_key)
		{
			fd_res = pNode->children[i];
			break;
		}
	}

	if (fd_res == FileAddr{ 0,0 })
	{
		return fd_res;
	}	
	else
	{
		BPlusTNode* pNextNode = FileAddrToMemPtr(fd_res);
		if (pNextNode->node_type == BTNodeType::LEAF)
			return SearchKey_Leaf(search_key, fd_res);
		else
			return SearchKey_Internal(search_key, fd_res);
	}
	//return fd_res;
}

FileAddr BPlusTree::SearchKey_Leaf(KeyAttr search_key, FileAddr node_fd)
{

	BPlusTNode* pNode = FileAddrToMemPtr(node_fd);
	for (int i = 0; i <pNode->key_totalnum; i++)
	{
		if (pNode->key[i] == search_key)
		{
			return pNode->children[i];
		}
	}
	return FileAddr{ 0,0 };
}

BPlusTNode * BPlusTree::FileAddrToMemPtr(FileAddr node_fd)
{
	auto pMemPage = GetGlobalPageManager()->GetMemAddr(File_ID, node_fd.filePageID);
	pMemPage->isModified = true;
	return (BPlusTNode*)((char*)pMemPage->PtrtoPageBegin + node_fd.offSet+sizeof(FileAddr));
}

void BPlusTNode::PrintBPlusTNode()
{
	using std::cout;
	using std::endl;
	cout << "Node Type: ";
	switch (node_type)
	{
	case BTNodeType::ROOT:
		cout << "ROOT";
		break;
	case BTNodeType::INTERNAL:
		cout << "INTERNAL";
		break;
	case BTNodeType::LEAF:
		cout << "LEAF";
		break;
	default:
		break;
	}
	cout << "\tkey_totalnum: " << key_totalnum << endl;

	for (int i = 0; i < key_totalnum; i++)
	{
		cout << "index: "<<i<<" key: " << key[i] << "\t" << "child addr: " << children[i].filePageID << " " << children[i].offSet << endl;
	}

}

