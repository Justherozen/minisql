#include "interpreter.h"

std::string CreateDbInfo(std::vector<std::string> sen_str)
{
	if ( (sen_str.size()!=3) 
		|| (Str2Lower(sen_str[0]) != "create") 
		|| (Str2Lower(sen_str[1]) != "database") 
		)
		throw SQLError::CMD_FORMAT_ERROR();
	return sen_str[2];
}

std::string UseDbInfo(std::vector<std::string> sen_str)
{
	if ((sen_str.size() != 3)
		|| (Str2Lower(sen_str[0]) != "use")
		|| (Str2Lower(sen_str[1]) != "database")
		)
		throw SQLError::CMD_FORMAT_ERROR();
	return sen_str[2];
}

std::string DropTableInfo(std::vector<std::string> sen_str)
{
	if ((sen_str.size() < 3)
		|| (Str2Lower(sen_str[0]) != "drop")
		|| (Str2Lower(sen_str[1]) != "table")
		)
		throw SQLError::CMD_FORMAT_ERROR();
	return sen_str[2];
}

TB_Select_Info TableSelectInfo(std::vector<std::string> sen_str)
{
	TB_Select_Info tb_select_info;
	// ѡ����ֶ�����
	if (Str2Lower(sen_str[0]) != "select")
		throw SQLError::CMD_FORMAT_ERROR();
	int name_L_index = 1;
	int name_R_index = 0;
	for (int i = 0; i < sen_str.size(); i++)
	{
		if (Str2Lower(sen_str[i]) == "from")
		{
			name_R_index = i-1;
			break;
		}
	}
	if(!name_R_index)
		throw SQLError::CMD_FORMAT_ERROR();
	for (int i = name_L_index; i <= name_R_index; i++)
	{
		tb_select_info.name_selected_column.push_back(sen_str[i]);
	}

	if(sen_str.size()-1 < (name_R_index+2))
		throw SQLError::CMD_FORMAT_ERROR();
	tb_select_info.table_name = sen_str[name_R_index + 2];

	int name_where_index = name_R_index + 3;
	if (sen_str.size() - 1 < name_where_index)
		return tb_select_info;

	auto mpair = GetColumnAndTypeFromTable(tb_select_info.table_name, GetCp().GetCurrentPath());
	// �����������
	for (int i = name_where_index + 1; i < sen_str.size();)
	{
		if (Str2Lower(sen_str[i]) == ";")
			break;
	    CompareCell cmp_cell = CreateCmpCell(sen_str[i], GetType(sen_str[i], mpair), GetOperatorType(sen_str[i + 1]), sen_str[i + 2]);
		tb_select_info.vec_cmp_cell.push_back(cmp_cell);

		// ��һ����������
		if ((i+3)<sen_str.size()&&Str2Lower(sen_str[i + 3]) == "and")
		{
			i += 4;
		}
		else
		{
			break;
		}
		
	}
	return tb_select_info;
}

TB_Delete_Info TableDeleteInfo(std::vector<std::string> sen_str)
{
	TB_Delete_Info tb_delete_info;
	tb_delete_info.table_name = sen_str[2];

	for (int i = 4; i < sen_str.size(); )
	{
		if (sen_str[i] == ";")
			break;
		TB_Delete_Info::Expr expr;
		expr.field = sen_str[i];
		expr.op = sen_str[i + 1];
		expr.value = sen_str[i + 2];
		tb_delete_info.expr.push_back(expr);
		i += 4;
	}
	if (sen_str.size() == 3) {
		tb_delete_info.deleteall = true;
	}
	else {
		tb_delete_info.deleteall = false;
	}
	return tb_delete_info;
}

Index_Info IndexInfo(std::vector<std::string> sen_str)
{
	Index_Info index_info;
	if ((sen_str.size() < 3) && (sen_str[0]) == "drop")
		throw SQLError::CMD_FORMAT_ERROR();
	if ((sen_str.size() < 3) && (sen_str[0]) == "create")
		throw SQLError::CMD_FORMAT_ERROR();
	if ((sen_str[0]) == "drop")
	{
		index_info.isCreate = false;
		index_info.table_name = sen_str[4];
	}
	else if ((sen_str[0]) == "create")
	{
		index_info.isCreate = true;
		index_info.table_name = sen_str[4];
		index_info.col_name = sen_str[5];
	}
	else
		throw SQLError::CMD_FORMAT_ERROR();
	index_info.index_name = sen_str[2];
	return index_info;
}

TB_Create_Info CreateTableInfo(std::vector<std::string> sen_str)
{
	TB_Create_Info tb_create_info;

	if (sen_str.size() < 3 || Str2Lower(sen_str[0]) != "create" || Str2Lower(sen_str[1]) != "table")
		throw SQLError::CMD_FORMAT_ERROR();
	// ����
	tb_create_info.table_name = sen_str[2];

	bool HasPrimary = false;
	// ���Ӹ����ֶ�
	for (int j = 3; j < sen_str.size();)
	{
		if (sen_str[j] == "primary" && sen_str[j + 1] == "key")
		{
			if (HasPrimary)
				throw SQLError::CMD_FORMAT_ERROR("Error!More than one primary key!");
			HasPrimary = true;
			string tmp = sen_str[j + 2];
			std::vector<TB_Create_Info::ColumnInfo>::iterator it = tb_create_info.columns_info.begin();
			for (; it < tb_create_info.columns_info.end(); it++)
				if (it->name.compare(tmp) == 0)
				{
					it->isPrimary = true;
					
					it->isUnique = true;
				}
			break;
		}
		TB_Create_Info::ColumnInfo column_info;
		column_info.isPrimary = false;
		column_info.isUnique = false;
		column_info.haveIndex = false;
		// ����
		column_info.name = sen_str[j];

		// ������
		if (j + 1 >= sen_str.size()) throw SQLError::CMD_FORMAT_ERROR();

		if (Str2Lower(sen_str[j + 1]) == "int")
		{
			column_info.type = Column_Type::I;
			column_info.length = sizeof(int);
			j += 2;
		}
		else if (Str2Lower(sen_str[j + 1]) == "float")
		{
			column_info.type = Column_Type::D;
			column_info.length = sizeof(double);
			j += 2;
		}
		else if (Str2Lower(sen_str[j + 1]) == "char")
		{
			column_info.type = Column_Type::C;
			if (j + 2 >= sen_str.size())throw SQLError::CMD_FORMAT_ERROR();
			column_info.length = stoi(sen_str[j + 2]);

			j += 3;
		}
		else
		{
			throw SQLError::CMD_FORMAT_ERROR("Unsupported data types!");
		}

		// �Ƿ�unique
		if (j < sen_str.size() && (sen_str[j] == "unique"))
		{
			column_info.isUnique = true;
			j++;
		}

		tb_create_info.columns_info.push_back(column_info);
	}
	if (!HasPrimary)
	{
		tb_create_info.columns_info[0].isPrimary = true;
		tb_create_info.columns_info[0].haveIndex = true;
	}
	return tb_create_info;
}

TB_Insert_Info CreateInsertInfo(std::vector<std::string> sen_str)
{
	TB_Insert_Info tb_insert_info;


	if (sen_str.size()<3 ||Str2Lower(sen_str[0]) != "insert" || Str2Lower(sen_str[1]) != "into")
		throw SQLError::CMD_FORMAT_ERROR();

	int values_index = -1;
	for (int i = 0; i < sen_str.size(); i++)
	{
		if (Str2Lower(sen_str[i]) == "values")
		{
			values_index = i;
			break;
		}
	}
	if (values_index <= 0)
		throw SQLError::CMD_FORMAT_ERROR();
	// ��ȡ����
	tb_insert_info.table_name = sen_str[2];
	int p,q;
	// ��ȡ�ֶ�
	if (sen_str[3] == "values") {
		tb_insert_info.isfull = true;
		for (q = values_index + 1; q < sen_str.size(); q++)
		{
			tb_insert_info.insert_info.push_back({"",sen_str[q] });
		}
	}
	else {
		tb_insert_info.isfull = false;
		for (p = 3, q = values_index + 1; p < values_index && q < sen_str.size(); p++, q++)
		{
			tb_insert_info.insert_info.push_back({ sen_str[p],sen_str[q] });
		}
		if ((p - 3) != (sen_str.size() - 1 - values_index))
			throw SQLError::CMD_FORMAT_ERROR("The size of fields is not match the size of values!");
	}
	return tb_insert_info;
}


CmdType GetOpType(std::vector<std::string> sen_str)
{
	for (auto&e : sen_str)
		Str2Lower(e);

	if (sen_str[0] == "create"&&sen_str[1] == "table")
	{
		return CmdType::TABLE_CREATE;
	}
		

	if (sen_str[0] == "create"&&sen_str[1] == "database")
	{
		return CmdType::DB_CREATE;
	}
		

	if (sen_str[0] == "drop"&&sen_str[1] == "table")
	{
		return CmdType::TABLE_DROP;
	}
		
	if (sen_str[0] == "use")
	{
		return CmdType::DB_USE;
	}

	if (sen_str[0] == "select")
	{
		return CmdType::TABLE_SELECT;
	}

	if (sen_str[0] == "insert")
	{
		return CmdType::TABLE_INSERT;
	}

	if (sen_str[0] == "delete")
	{
		return CmdType::TABLE_DELETE;
	}

	if (sen_str[0] == "quit")
	{
		return CmdType::QUIT;
	}
	if (sen_str[0] == "help")
	{
		return CmdType::HELP;
	}
	if (sen_str[0] == "execfile")
	{
		return CmdType::EXECFILE;
	}
	if (sen_str[0] == "create"&&sen_str[1] == "index"&&sen_str[3]=="on")
	{
		return CmdType::INDEX;
	}
	if (sen_str[0] == "drop"&&sen_str[1] == "index"&&sen_str[3] == "on")
	{
		return CmdType::INDEX;
	}
	throw SQLError::CMD_FORMAT_ERROR();

}


bool CompareCell::operator()(const Column_Cell &cc)
{
	switch (cmp_value.column_type)
	{
	case Column_Type::I:
		switch (OperType)
		{
		case B:
			return cc.column_value.IntValue > cmp_value.column_value.IntValue;
			break;
		case BE:
			return cc.column_value.IntValue >= cmp_value.column_value.IntValue;
			break;
		case L:
			return cc.column_value.IntValue < cmp_value.column_value.IntValue;
			break;
		case LE:
			return cc.column_value.IntValue <= cmp_value.column_value.IntValue;
			break;
		case E:
			return cc.column_value.IntValue == cmp_value.column_value.IntValue;
			break;
		case NE:
			return cc.column_value.IntValue != cmp_value.column_value.IntValue;
			break;
		default:
			return false;
			break;
		}
		break;
	case Column_Type::D:
		switch (OperType)
		{
		case B:
			return cc.column_value.DoubleValue > cmp_value.column_value.DoubleValue;
			break;
		case BE:
			return cc.column_value.DoubleValue >= cmp_value.column_value.DoubleValue;
			break;
		case L:
			return cc.column_value.DoubleValue < cmp_value.column_value.DoubleValue;
			break;
		case LE:
			return cc.column_value.DoubleValue <= cmp_value.column_value.DoubleValue;
			break;
		case E:
			return cc.column_value.DoubleValue == cmp_value.column_value.DoubleValue;
			break;
		case NE:
			return cc.column_value.DoubleValue != cmp_value.column_value.DoubleValue;
			break;
		default:
			return false;
			break;
		}
		break;
	case Column_Type::C:
		switch (OperType)
		{
		case B:
			return std::string(cc.column_value.StrValue) > std::string(cmp_value.column_value.StrValue);
			break;
		case BE:
			return std::string(cc.column_value.StrValue) >= std::string(cmp_value.column_value.StrValue);
			break;
		case L:
			return std::string(cc.column_value.StrValue) < std::string(cmp_value.column_value.StrValue);
			break;
		case LE:
			return std::string(cc.column_value.StrValue) <= std::string(cmp_value.column_value.StrValue);
			break;
		case E:
			return std::string(cc.column_value.StrValue) == std::string(cmp_value.column_value.StrValue);
			break;
		case NE:
			return std::string(cc.column_value.StrValue) != std::string(cmp_value.column_value.StrValue);
			break;
		default:
			return false;
			break;
		}
		break;
	default:
		return false;
		break;
	}
	return false;
}


void PrintWindow::CreateTable(bool is_created)
{
	if (is_created)
	{
		std::cout << "table create succeed!" << std::endl;
	}
	else
	{
		std::cout << "table create failed!" << std::endl;
	}
}


void PrintWindow::DropTable(bool is_dropped)
{
	if (is_dropped)
	{
		std::cout << "Drop table succeed!" << std::endl;
	}
	else
	{
		std::cout << "Drop table failed!" << std::endl;
	}
}


void PrintWindow::SelectTable(SelectPrintInfo select_table_print_info)
{
	for (auto it = select_table_print_info.name_selected_column.begin(); it != select_table_print_info.name_selected_column.end();)
	{
		if (*it == ",")
		{
			select_table_print_info.name_selected_column.erase(it);
		}
		else
		{
			it++;
		}
	}
	if (select_table_print_info.key_fd.size() < 1)
		return;
	std::string idx_file = GetCp().GetCurrentPath() + select_table_print_info.table_name + ".idx";
	std::string dbf_file = GetCp().GetCurrentPath() + select_table_print_info.table_name + ".dbf";
	BPlusTree tree(idx_file);
	TableIndexHeadInfo table_index_head_info(tree);
	int total_length = 0;
	auto key_fd = select_table_print_info.key_fd;
	
	

	auto all_column_name = table_index_head_info.GetColumnNames();
	auto all_column_len = table_index_head_info.GetColumnSize();
	std::vector<std::string> out_name = select_table_print_info.name_selected_column;
	if (out_name.size() == 1 && out_name[0] == "*")
		out_name = all_column_name;
	int n_output_col = out_name.size();

	int total_record_len = 2;
	std::vector<int> out_len;
	for (int i = 0; i < out_name.size(); i++)
	{
		auto it = find(all_column_name.begin(), all_column_name.end(), out_name[i]);
		Column_Type type = table_index_head_info.GetColumnType()[it - all_column_name.begin()];
		switch (type)
		{
		case Column_Type::I:
			out_len.push_back(8);
			total_record_len += 8;
			break;
		case Column_Type::C:
			out_len.push_back(all_column_len[it - all_column_name.begin()]);
			total_record_len += all_column_len[it - all_column_name.begin()];
			break;
		case Column_Type::D:
			out_len.push_back(15);
			total_record_len += 15;
			break;
		default:
			break;
		}
	}
	
	total_record_len += (out_name.size() - 1);
	//��ӡͷ��
	std::cout << "+";
	for (int i = 0; i < out_name.size(); i++)
	{
		int len = out_len[i] + 1;
		if (i == out_name.size() - 1)len--;
		for (int j = 0; j < len; j++)
		{
			std::cout << "-";
		}
			
	}
	std::cout << "+";


	std::cout << std::endl;
	// ��ӡ����
	for (int i = 0; i < out_name.size(); i++)
	{
		std::cout << "|" << std::left << std::setw(out_len[i]) << out_name[i];
	}
	std::cout << "|" << std::endl;
	// �ָ���
	std::cout << "+";
	for (int i = 0; i < total_record_len - 2; i++)std::cout << "-";
	std::cout << "+" << std::endl;

	// ��ӡÿһ����¼
	for (int i = 0; i < key_fd.size(); i++)
	{
		RecordHead record_head = GetDbfRecord(select_table_print_info.table_name, key_fd[i].second, GetCp().GetCurrentPath());
		auto pColumn = record_head.GetFirstColumn();
		while (pColumn)
		{
			auto it = find(out_name.begin(), out_name.end(), pColumn->columu_name);
			if (it != out_name.end())
			{
				switch (pColumn->column_type)
				{
				case Column_Type::I:
					std::cout << "|" << std::left << std::setw(out_len[it-out_name.begin()]) << pColumn->column_value.IntValue;
					break;
				case Column_Type::D:
					
					std::cout << "|" << std::left << std::setw(out_len[it - out_name.begin()]) << pColumn->column_value.DoubleValue;
					break;
				case Column_Type::C:
					
					std::cout << "|" << std::left << std::setw(out_len[it - out_name.begin()]) << pColumn->column_value.StrValue;
					break;
				default:
					break;
				}
			}
			pColumn = pColumn->next;
		}
		std::cout <<"|"<< std::endl;
	}



	// ������һ��
	std::cout << "+";
	for (int i = 0; i < total_record_len - 2; i++)std::cout << "-";
	std::cout << "+";
	std::cout << std::endl;

	std::cout << select_table_print_info.key_fd.size() << " row in set.[";
	GetTimer().PrintTimeSpan();
	std::cout << "used.]" << std::endl;
}

void PrintWindow::InsertRecord(bool is_inserted,int isExecfile)
{
	if (is_inserted)
	{
		if(!isExecfile)std::cout << "Insert succeed!" << std::endl;
	}
	else
	{
		std::cout << "Insert failed!" << std::endl;
	}
}

void PrintWindow::CreateDB(bool is_created)
{
	if (is_created)
	{
		std::cout << "Create succeed!" << std::endl;
	}
	else
	{
		std::cout << "Create failed!" << std::endl;
	}
}

void PrintWindow::UseDB(bool isUsed)
{
	if (isUsed)
	{
		std::cout << "database changed!" << std::endl;
	}
	else
	{
		std::cout << "database absent" << std::endl;
	}
}

void PrintWindow::DeleteTable(bool isDeleted,int isExecfile)
{
	if (isDeleted)
	{
		if(!isExecfile)std::cout << "Delete succeed!" << std::endl;
	}
	else
	{
		std::cout << "Delete failed" << std::endl;
	}
}

void PrintWindow::doIndex(bool isDone)
{
	if (isDone)
	{
		std::cout << "Index operation succeed!" << std::endl;
	}
	else
	{
		std::cout << "Index operation failed" << std::endl;
	}
}

void PrintWindow::Print(int len, std::string s)
{
	std::cout << "|";
	std::cout << s;
	for (int i = 0; i < (PRINTLENGTH - s.size()); i++)std::cout << " ";
	std::cout << "|";
	std::cout << std::endl;

}

int PrintWindow::GetColumnLength(std::string name, std::vector<std::string> col_name, std::vector<int> col_len)
{
	for (int j = 0; j < col_name.size(); j++)
	{
		if (name == col_name[j])
		{
			return col_len[j]>col_name[j].size()? col_len[j]:col_name[j].size();
		}
	}
	return 0;
}

void Interpreter(std::vector<std::string> sen_str, CmdType cmd_type, PrintWindow print_window,int isExecfile)
{
	auto &cp = GetCp();
	TB_Select_Info tb_select_info;
	std::vector<FileAddr> fds;


	switch (cmd_type)
	{
	case CmdType::TABLE_CREATE:      // ������
		print_window.CreateTable(CreateTable(CreateTableInfo(sen_str), cp.GetCurrentPath()));
		break;

	case CmdType::TABLE_DROP:        // ɾ����
		print_window.DropTable(DropTable(DropTableInfo(sen_str), cp.GetCurrentPath()));
		break;

	case CmdType::TABLE_SELECT:      // ѡ������ض���¼
		print_window.SelectTable(SelectTable(TableSelectInfo(sen_str), cp.GetCurrentPath()));
		break;

	case CmdType::TABLE_INSERT:      // �����µļ�¼
		print_window.InsertRecord(InsertRecord(CreateInsertInfo(sen_str), cp.GetCurrentPath()),isExecfile);
		break;

	case CmdType::TABLE_DELETE:      // ɾ�����ļ�¼
		print_window.DeleteTable(DeleteTable(TableDeleteInfo(sen_str), cp.GetCurrentPath()),isExecfile);
		break;

	case CmdType::DB_CREATE:         // �������ݿ�
		print_window.CreateDB(CreateDatabase(CreateDbInfo(sen_str), cp));
		break;

	case CmdType::DB_USE:            // ʹ�����ݿ�
		print_window.UseDB(UseDatabase(UseDbInfo(sen_str), cp));
		break;

	case CmdType::INDEX:         // ����/ɾ������
		print_window.doIndex(doIndex(IndexInfo(sen_str), cp.GetCurrentPath()));
		break;

	default:
		throw SQLError::CMD_FORMAT_ERROR();
		break;
	}
}

SensefulStr::SensefulStr(std::string srcstr /*= ""*/)
	:src_str(srcstr)
{
	Parse();
}

void SensefulStr::SetSrcStr(std::string _srcstr)
{
	src_str = _srcstr;
	sen_str.clear();
	Parse();
}

std::vector<std::string> SensefulStr::GetSensefulStr() const
{
	return sen_str;
}

void SensefulStr::Parse()
{
	int i = 0;
	sen_str.clear();
	std::string token;
	while (i < src_str.size())
	{
		if (src_str[i] == 34 || src_str[i] == 39)
		{
			token.clear();
			i++;
			while ((src_str[i] != 34) && (src_str[i] != 39))
			{
				token += src_str[i];
				i++;
			}
			i++;
			sen_str.push_back(token);
			token.clear();
			continue;
		}
		if (IsKeyChar(src_str[i]))
		{
			if (!token.empty())
				sen_str.push_back(token);
			token.clear();
			// �����ؼ��ַ�������>=<�ȽϷ�
			while (IsKeyChar(src_str[i]))
			{
				std::string tmp_token;
				if (src_str[i] == '>' || src_str[i] == '=' || src_str[i] == '<')  // �ȽϷ���
				{
					tmp_token += src_str[i];
					if (src_str[i + 1] == '=')
					{
						tmp_token += src_str[i + 1];
						i += 2;
					}
					else if(src_str[i] == '<' && src_str[i+1] == '>')
					{
						tmp_token += src_str[i + 1];
						i += 2;
					}
					else
					{
						i++;
					}
					sen_str.push_back(tmp_token);
				}
				else
				{
					i++;
				}
			}

		}
		else
		{
			token += src_str[i];
			i++;
		}
	}
}

bool SensefulStr::IsKeyChar(char c)
{
	auto it = std::find(key_char.begin(),key_char.end(),c);
	return (it != key_char.end());
}
