#include "timer.h"

std::string Idx2Dbf(std::string idx_name)
{
	std::string dbf_name(idx_name);

	int i = idx_name.size()-1;
	while (idx_name[i] != '.')
		i--;
	if (i < 0) throw SQLError::FILENAME_CONVERT_ERROR();
	idx_name[i + 1] = 'd';
	idx_name[i + 2] = 'b';
	idx_name[i + 3] = 'f';
	idx_name[i + 4] = '\0';

	return dbf_name;
}

std::string Dbf2Idx(std::string dbf_name)
{
	std::string idx_name(dbf_name);

	int i = idx_name.size() - 1;
	while (idx_name[i] != '.')
		i--;
	if (i < 0) throw SQLError::FILENAME_CONVERT_ERROR();
	idx_name[i + 1] = 'i';
	idx_name[i + 2] = 'd';
	idx_name[i + 3] = 'x';
	idx_name[i + 4] = '\0';

	return idx_name;
}


std::string Str2Lower(std::string str)
{
	for (auto &c : str)
		tolower(c);
	return str;
}



void SQLTimer::Start()
{
	start_t = steady_clock::now();
}

void SQLTimer::Stop()
{
	stop_t = steady_clock::now();
}
double SQLTimer::TimeSpan()
{
	time_span = duration_cast<duration<double>>(stop_t - start_t)*0.85;
	return time_span.count();
}

void SQLTimer::PrintTimeSpan()
{
	std::cout << std::setiosflags(std::ios::fixed) << std::setprecision(precision) << TimeSpan() << " seconds ";
}

SQLTimer& GetTimer1(int i)
{
	static SQLTimer timer1[4];
	return timer1[i];
}
SQLTimer& GetTimer()
{
	static SQLTimer timer;
	return timer;
}