﻿#include <iostream>
#include <random>
#include <fstream>
#include <ctime>
#include "./INTERPRETER/interpreter.h"
#include "./ERRORREPORTER/error_Reporter.h"
using namespace std;
void ShowHelp();
void ShowStarter();
void RunMiniSQL();
void MySleep(unsigned int n = 1); // 程序睡眠
string GetCommand(int type, std::ifstream* in_ptr); // 读取用户的输入，以 ";"结束
const string PROMPT = "MiniSQL:";
int isExecfile = 0;
vector<string> filename;
int main()
{
	// Initialize DB
	ShowStarter();

	// Run DB
	RunMiniSQL();

	// Exit DB
	cout << "Thanks for using our minisql!" << endl;

	MySleep();

	return 0;
}

void ShowStarter()
{

	cout << "(+---------------------------------------------------------------------+)" << endl;
	cout << "(|                  Welcome to our Minisql!                            |)" << endl;
	cout << "(|                                                                     |)" << endl;
	cout << "(|*You can type a standard SQL statement that ends with; one at a time.|)" << endl;
	cout << "(|*You can type \'quit;\' to quit the minisql console.                  |)" << endl;
	cout << "(|*You can type \'help;\' to get help                                   |)" << endl;
	cout << "(|*Have fun and enjoy yourself!                                        |)" << endl;
	cout << "(|*Currently supported data types are int,double and char.             |)" << endl;
	cout << "(|                                                                     |)" << endl;
	cout << "(|Provided by ZJU DBS group:Fu Ziyang,Xiao Ruixuan and Sun Jiayang     |)" << endl;
	cout << "(+---------------------------------------------------------------------+)" << endl;

}


void RunMiniSQL()
{
	SensefulStr senstr;
	PrintWindow print_window;
	std::ifstream in[20];
	std::ifstream* in_ptr = in;
	int this_file = -1;
	int type = 0;
	std::string path = "./TEST/";
	while (true)
	{
		try
		{
			GetTimer1(this_file).Stop();
			string cmd = GetCommand(type, in_ptr);
			if (cmd == "EOF")
			{

				this_file--;
				(*in_ptr).close();
				if (this_file != -1)
				{
					in_ptr = &(in[this_file]);
				}
				else
					type = 0;
				
				cout << "execfile "+ filename.back()<<" succeed! [" ;
				GetTimer1(this_file+1).PrintTimeSpan();
				std::cout << "used.]" << std::endl;
				filename.pop_back();
				continue;
			}
			senstr.SetSrcStr(cmd);

			auto cmd_type = GetOpType(senstr.GetSensefulStr());

			if (cmd_type == CmdType::QUIT)break;
			if (cmd_type == CmdType::HELP)
			{
				ShowHelp();
				continue;
			}
			if (cmd_type == CmdType::EXECFILE)
			{
				std::vector<std::string> tmp = senstr.GetSensefulStr();
				++this_file;
				in[this_file].open(path + tmp[1]);
				in_ptr = &(in[this_file]);
				type = 1;
				isExecfile = 1;
				filename.push_back(tmp[1]);
				GetTimer1(this_file).Start();
				continue;
			}
			else if (this_file == -1)isExecfile = 0;
			Interpreter(senstr.GetSensefulStr(), cmd_type, print_window, isExecfile);
		}
		catch (SQLError::BaseError &e)
		{
			SQLError::DispatchError(e);
			cout << endl;
			continue;
		}

	}
}


void ShowHelp()
{
	cout << R"(+------------------------------------------------------------------------------------------------+)" << endl;
	cout << R"(|A simple example to create a student databae named STU                                          |)" << endl;
	cout << R"(+------------------------------------------------------------------------------------------------+)" << endl;
	cout << R"(|Create database  : create database DBS;                                                         |)" << endl;
	cout << R"(|Use database     : use database DBS;                                                            |)" << endl;
	cout << R"(|Show database    : show databases;                                                              |)" << endl;
	cout << R"(|Create Table     : create table student(id int, score float, name char(20),primary key (id));   |)" << endl;
	cout << R"(|Insert Record(1) : insert into student values(1,95.5,ZhangSan);							        |)" << endl;
	cout << R"(|Insert Record(2) : insert into student(id,name)values(2,LiSi); Note:LiSi has no score           |)" << endl;
	cout << R"(|UPDATE Table     : update student set score = 96.5 where name = LiSi;                           |)" << endl;
	cout << R"(|Delete Table     : delete from student where id = 1; Note: ZhangSan is deleted                  |)" << endl;
	cout << R"(|Select Table(1)  : select * from student where id = 2;                                          |)" << endl;
	cout << R"(|Select Table(2)  : select * from student where id > 1 and score < 98;                           |)" << endl;
	cout << R"(|Select Table(3)  : select id,score from student where id > 1 and score < 98;                    |)" << endl;
	cout << R"(|Drop database    : drop database DBS;                                                           |)" << endl;
	cout << R"(|Quit             : quit;                                                                        |)" << endl;
	cout << R"(+------------------------------------------------------------------------------------------------+)" << endl;
	cout << R"(|Note             : Anytime you want to end MiniSQL use "quit;" command please.                  |)" << endl;
	cout << R"(+------------------------------------------------------------------------------------------------+)" << endl;
}

string GetCommand(int type, std::ifstream *in_ptr)
{
	string res;
	string tmp;
	int n = 0;

	if (type == 0)
	{
		if (n == 0) {
			cout << PROMPT;
		}
		else {
			cout << "        ";
		}
		n++;
		getline(cin, tmp, ';');
		if (cin.eof())
			return "EOF";
		
	}
	else
	{	
		getline(*in_ptr, tmp, ';');
		if (in_ptr->eof())
			return "EOF";
		else {
			if (!isExecfile) {
				if (n == 0) {
					cout << PROMPT;
				}
				else
				{
					cout << "        ";
				}
				n++;
			}
		}
	}
	res += tmp + ";";
	return res;
}

void MySleep(unsigned int n)
{
	auto t1 = time(0);
	time_t t2 = t1;
	while ((t2 - t1) < n)
	{
		t2 = time(0);
	}
}
