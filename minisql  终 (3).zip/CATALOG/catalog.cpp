#include "catalog.h"


CompareCell CreateCmpCell(std::string column_name, Column_Type column_type, Operator_Type Optype, std::string value)
{

	Column_Cell column_cell;
	column_cell.columu_name = column_name;
	Column_Type tmp = column_type;
	char*pChar = nullptr;
	switch (tmp)
	{
	case Column_Type::I:
		column_cell.column_type = Column_Type::I;
		column_cell.column_value.IntValue = stoi(value);
		break;

	case Column_Type::C:
		column_cell.column_type = Column_Type::C;
		pChar = (char*)malloc(value.size() + 1);
		strcpy(pChar, value.c_str());
		column_cell.column_value.StrValue = pChar;
		break;

	case Column_Type::D:
		column_cell.column_type = Column_Type::D;
		column_cell.column_value.DoubleValue = stod(value);
		break;
	default:
		break;
	}
	CompareCell cmp_cell(Optype, column_cell);

	return cmp_cell;
}
Operator_Type GetOperatorType(std::string s)
{
	s = Str2Lower(s);
	if (s == ">")
	{
		return Operator_Type::B;
	}
	else if (s == ">=")
	{
		return Operator_Type::BE;
	}
	else if (s == "<")
	{
		return Operator_Type::L;
	}
	else if (s == "<=")
	{
		return Operator_Type::LE;
	}
	else if (s == "=")
	{
		return Operator_Type::E;
	}
	else if (s == "!=")
	{
		return Operator_Type::NE;
	}
	else
	{
		return Operator_Type::B;
	}
}
CatalogPosition& GetCp()
{
	static CatalogPosition cp;
	return cp;
}
bool CatalogPosition::isInSpeDb = false;

CatalogPosition::CatalogPosition()
	:root("./DB/"), current_catalog("./DB/")
{
	// �����ǰĿ¼��û�� DB �ļ����򴴽�
	std::string tmp_path = "./DB";

	if (_access(tmp_path.c_str(), 0) == -1)
	{
		_mkdir(tmp_path.c_str());
	}
}

bool CatalogPosition::ResetRootCatalog(std::string root_new)
{
	if (root_new[root_new.size() - 1] == '/')
	{
		root = root_new;
		current_catalog = root;
		isInSpeDb = false;
		return true;
	}
	else
	{
		return false;
	}
}

void CatalogPosition::SwitchToDatabase()
{
	current_catalog = root;
	isInSpeDb = false;
}

bool CatalogPosition::SwitchToDatabase(std::string db_name)
{
	std::string tmp_path = root + db_name;

	if (_access(tmp_path.c_str(), 0) == -1)  //�ж����ݿ��Ƿ����
	{
		return false;
	}
	else
	{
		current_catalog = root + db_name + "/";
		isInSpeDb = true;
		return true;
	}

}

std::string CatalogPosition::GetCurrentPath() const
{
	return current_catalog;
}

std::string CatalogPosition::GetRootPath() const
{
	return root;
}

std::string CatalogPosition::SetCurrentPath(std::string cur)
{
	current_catalog = cur;
	return current_catalog;
}

size_t TableIndexHeadInfo::GetColumnCount()const
{
	size_t n = 0;

	const IndexHeadNode* pHeadNode = tree.GetIdxHeadNodePtr();
	const char *pColumnTypeInfo = pHeadNode->RecordTypeInfo;

	while ((*pColumnTypeInfo) != '\0')
	{
		char c = *pColumnTypeInfo;
		if (c == 'I' || c == 'D' || c == 'C')  n++;
		pColumnTypeInfo++;
	}

	return n;
}
std::vector<std::string> TableIndexHeadInfo::GetColumnNames() const
{
	std::vector<std::string> column_names;
	size_t column_count = GetColumnCount();

	const IndexHeadNode* pHeadNode = tree.GetIdxHeadNodePtr();
	const char *pColumnName = pHeadNode->RecordColumnName;
	for (size_t i = 0; i < column_count; i++)
	{
		column_names.push_back(pColumnName);
		pColumnName += ColumnNameLength;
	}

	return column_names;
}

std::vector<Column_Type> TableIndexHeadInfo::GetColumnType()const
{
	std::vector<Column_Type> column_types;

	const IndexHeadNode* pHeadNode = tree.GetIdxHeadNodePtr();
	const char *pColumnTypeInfo = pHeadNode->RecordTypeInfo;

	while ((*pColumnTypeInfo) != '\0')
	{
		char c = *pColumnTypeInfo;

		switch (c)
		{
		case 'I':
			column_types.push_back(Column_Type::I);
			break;
		case 'D':
			column_types.push_back(Column_Type::D);
			break;
		case 'C':
			column_types.push_back(Column_Type::C);
			break;

		default:
			break;
		}

		pColumnTypeInfo++;
	}

	return column_types;
}

Column_Type TableIndexHeadInfo::GetColumnType(std::string column_name) const
{
	auto column_names = GetColumnNames();
	int k = 0;
	for (int i = 0; i < column_names.size(); i++)
	{
		if (column_names[i] == column_name)
		{
			k = i;
			break;
		}
	}

	auto column_types = GetColumnType();
	return column_types[k];
}

std::vector<int> TableIndexHeadInfo::GetColumnSize() const
{
	std::vector<int> column_size;

	const IndexHeadNode* pHeadNode = tree.GetIdxHeadNodePtr();
	const char *pColumnTypeInfo = pHeadNode->RecordTypeInfo;

	while ((*pColumnTypeInfo) != '\0')
	{
		char c = *pColumnTypeInfo;
		size_t sz = 0;
		switch (c)
		{
		case 'I':
			column_size.push_back(sizeof(int));
			break;
		case 'D':
			column_size.push_back(sizeof(double));
			break;
		case 'C':
			sz = (pColumnTypeInfo[1] - '0') * 100 + (pColumnTypeInfo[2] - '0') * 10 + (pColumnTypeInfo[3] - '0') * 1;
			column_size.push_back(sz);
			break;

		default:
			break;
		}

		pColumnTypeInfo++;
	}

	return column_size;
}

int TableIndexHeadInfo::GetColumnSizeByIndex(int i) const
{
	auto SZ = GetColumnSize();
	return SZ[i];
}

int TableIndexHeadInfo::GetPrimaryIndex()const
{
	const IndexHeadNode* pHeadNode = tree.GetIdxHeadNodePtr();
	return pHeadNode->PrimaryKey;
}

bool TableIndexHeadInfo::IsColumnName(std::string column_name) const
{
	auto table_names = GetColumnNames();
	auto pos = std::find(table_names.begin(), table_names.end(), column_name);

	return pos != table_names.end();
}

int TableIndexHeadInfo::GetIndex(std::string column_name) const
{
	auto names = GetColumnNames();
	for (int i = 0; i < names.size(); i++)
	{
		if (names[i] == column_name)
			return i;
	}
	return 0;
}
std::vector<std::string> TableIndexHeadInfo::GetColumnIndex() const
{
	std::vector<std::string> column_names;
	size_t column_count = GetColumnCount();

	const IndexHeadNode* pHeadNode = tree.GetIdxHeadNodePtr();
	const char *pColumnName = pHeadNode->IndexName;
	for (size_t i = 0; i < column_count; i++)
	{
		column_names.push_back(pColumnName);
		pColumnName += ColumnNameLength;
	}
	return column_names;
}
int   TableIndexHeadInfo::GetIndexFile(std::string column_name)const {
	std::vector<std::string> column_names;
	size_t column_count = GetColumnCount();

	const IndexHeadNode* pHeadNode = tree.GetIdxHeadNodePtr();
	const char *pColumnName = pHeadNode->IndexName;
	for (size_t i = 0; i < column_count; i++)
	{
		column_names.push_back(pColumnName);
		pColumnName += ColumnNameLength;
	}

	for (int i = 0; i < column_names.size(); i++)
	{
		if (column_names[i] == column_name)
			return i;
	}
	return -1;
}
bool TableIndexHeadInfo::IsPrimary(std::string column_name) const
{
	auto column_names = GetColumnNames();
	auto index = GetPrimaryIndex();
	if (!column_names.empty())
	{
		return column_names[index] == column_name;
	}
	return false;
}
bool TableIndexHeadInfo::IsUnique(std::string column_name) const {
	int index = GetIndex(column_name);
	const IndexHeadNode* pHeadNode = tree.GetIdxHeadNodePtr();
	return pHeadNode->UniqueInfo[index];
}

bool TableIndexHeadInfo::IsUniqueBuild(std::string column_name) const {
	int index = GetIndex(column_name);
	const IndexHeadNode* pHeadNode = tree.GetIdxHeadNodePtr();
	return pHeadNode->IsUniqueBuild[index];
}

int TableIndexHeadInfo::GetColumnOffset(std::string column_name)
{
	std::vector<int> column_size = GetColumnSize();
	int index = GetIndex(column_name);

	size_t offset = 0;
	for (int i = 0; i < index; i++)
		offset += column_size[i];
	return offset;
}

void Check_TB_Create_Info(const TB_Create_Info &tb_create_info)
{
	// ����
	std::string table_name = tb_create_info.table_name;
	std::string idx_file = GetCp().GetCurrentPath() + table_name + ".idx";
	// �жϱ��Ƿ��Ѿ�����
	if (_access(idx_file.c_str(), 0) != -1) {  //������
		throw SQLError::TABLE_ERROR("The table already exists!");
	}

	// ���ÿ���ֶε���Ϣ
	for (int i = 0; i < tb_create_info.columns_info.size(); i++)
	{
		auto &column = tb_create_info.columns_info[i];

		// ����ֶ����Ƴ���
		if (column.name.size() >= ColumnNameLength)
			throw SQLError::TABLE_ERROR("Error!Column name length overflow");

		// ����ֶ�����
		if (column.type != Column_Type::C && column.type != Column_Type::D&& column.type != Column_Type::I)
			throw SQLError::TABLE_ERROR("Column data type error!");
	}

	// ����Ƿ����ؼ���
	int primary_count = 0;
	for (auto &e : tb_create_info.columns_info)
		if (e.isPrimary) primary_count++;

	if (primary_count > 1)
		throw SQLError::TABLE_ERROR("Error!More than one primary key!");


	// ����ֶθ���
	if (tb_create_info.columns_info.size() > RecordColumnCount)
		throw SQLError::TABLE_ERROR("Error!Column count is overflow!");
}

void Check_TB_Insert_Info(const TB_Insert_Info &tb_insert_info)
{
	std::string idx_file = GetCp().GetCurrentPath() + tb_insert_info.table_name + ".idx";

	// ������ھ������ݿ�Ŀ¼�£����ܲ����¼
	if (!GetCp().GetIsInSpeDb())
		throw SQLError::TABLE_ERROR("Error!Not use database!");

	// �жϱ��Ƿ��Ѿ�����
	if (_access(idx_file.c_str(), 0) == -1) {  //��������
		throw SQLError::TABLE_ERROR("The table is not exists!");
	}

	BPlusTree tree(idx_file);
	TableIndexHeadInfo table_index_head_info(tree);

	// �����������ֶε���Ϣ
	for (int i = 0; i < tb_insert_info.insert_info.size(); i++)
	{
		auto &cur_columu = tb_insert_info.insert_info[i];
		// �ж��ֶ��Ƿ�Ϸ�
		if (!table_index_head_info.IsColumnName(cur_columu.column_name))
			throw SQLError::TABLE_ERROR("Fields do not exist!");

		// ����ֶδ�С
		int index = table_index_head_info.GetIndex(cur_columu.column_name);
		Column_Type column_type = table_index_head_info.GetColumnType(cur_columu.column_name);
		int column_size = table_index_head_info.GetColumnSizeByIndex(index);
		if (column_type == Column_Type::C && cur_columu.column_value.size() > column_size)
			throw SQLError::TABLE_ERROR("Field length overflow!");

		// ��������������ַ����ֶ�
		if (table_index_head_info.IsPrimary(cur_columu.column_name))
		{
			if (column_type == Column_Type::C && (cur_columu.column_value.size() > column_size) || cur_columu.column_value.size() > ColumnNameLength)
				throw SQLError::TABLE_ERROR("Primary key field length overflow!");
		}


	}
}

void Check_TB_Update_Info(const TB_Update_Info &tb_update_info)
{
	std::string idx_file = GetCp().GetCurrentPath() + tb_update_info.table_name + ".idx";

	// ������ھ������ݿ�Ŀ¼�£����ܲ����¼
	if (!GetCp().GetIsInSpeDb())
		throw SQLError::TABLE_ERROR("Error!Not use database!");

	// �жϱ��Ƿ��Ѿ�����
	if (_access(idx_file.c_str(), 0) == -1) {  //��������
		throw SQLError::TABLE_ERROR("The table is not exists!");
	}

	BPlusTree tree(idx_file);
	TableIndexHeadInfo table_index_head_info(tree);

	// ���Ҫ���µ���ֵ
	for (int j = 0; j < tb_update_info.field_value.size(); j++)
	{
		auto &new_value = tb_update_info.field_value[j];
		// ����ֶ�����
		if (!table_index_head_info.IsColumnName(new_value.field))
			throw SQLError::TABLE_ERROR("Fields do not exist!");

		// ����ֶδ�С
		int index = table_index_head_info.GetIndex(new_value.field);
		Column_Type column_type = table_index_head_info.GetColumnType(new_value.field);
		int column_size = table_index_head_info.GetColumnSizeByIndex(index);
		if (column_type == Column_Type::C && new_value.field.size() > column_size)
			throw SQLError::TABLE_ERROR("Field length overflow!");

		// ��������������ַ����ֶ�
		if (table_index_head_info.IsPrimary(new_value.field))
		{
			if (column_type == Column_Type::C && (new_value.field.size() > column_size) || new_value.field.size() > ColumnNameLength)
				throw SQLError::TABLE_ERROR("Primary key field length overflow!");
		}
	}

	// ����������
	for (int j = 0; j < tb_update_info.expr.size(); j++)
	{
		auto &expr_tmp = tb_update_info.expr[j];
		// ����ֶ�����
		if (!table_index_head_info.IsColumnName(expr_tmp.field))
			throw SQLError::TABLE_ERROR("Where Expr Fields do not exist!");
		if (expr_tmp.op != ">"&& expr_tmp.op != "=" && expr_tmp.op != "<" && expr_tmp.op != ">=" && expr_tmp.op != "<=" && expr_tmp.op != "!=")
			throw SQLError::TABLE_ERROR("Where Expr relational operator error!");

	}
}

void Check_TB_Delete_Info(const TB_Delete_Info &tb_delete_info)
{
	std::string idx_file = GetCp().GetCurrentPath() + tb_delete_info.table_name + ".idx";
	BPlusTree tree(idx_file);
	TableIndexHeadInfo table_index_head_info(tree);

	// ������ھ������ݿ�Ŀ¼�£����ܲ����¼
	if (!GetCp().GetIsInSpeDb())
		throw SQLError::TABLE_ERROR("Error!Not use database!");

	// �жϱ��Ƿ��Ѿ�����
	if (_access(idx_file.c_str(), 0) == -1) {  //��������
		throw SQLError::TABLE_ERROR("The table is not exists!");
	}

	// ���ɾ������
	for (int j = 0; j < tb_delete_info.expr.size(); j++)
	{
		auto &expr_tmp = tb_delete_info.expr[j];
		// ����ֶ�����
		if (!table_index_head_info.IsColumnName(expr_tmp.field))
			throw SQLError::TABLE_ERROR("Where Expr Fields do not exist!");
		if (expr_tmp.op != ">" && expr_tmp.op != "=" && expr_tmp.op != "<" && expr_tmp.op != ">=" && expr_tmp.op != "<=" && expr_tmp.op != "!=")
			throw SQLError::TABLE_ERROR("Where Expr relational operator error!");
	}
}

void Check_TB_Select_Info(const TB_Select_Info &tb_select_info)
{
	std::string idx_file = GetCp().GetCurrentPath() + tb_select_info.table_name + ".idx";
	BPlusTree tree(idx_file);
	TableIndexHeadInfo table_index_head_info(tree);

	// ������ھ������ݿ�Ŀ¼�£����ܲ����¼
	if (!GetCp().GetIsInSpeDb())
		throw SQLError::TABLE_ERROR("Error!Not use database!");
	// �жϱ��Ƿ��Ѿ�����
	if (_access(idx_file.c_str(), 0) == -1) {  //��������
		throw SQLError::TABLE_ERROR("The table is not exists!");
	}
	// ���Ҫ��ʾ���ֶ�����
	if (tb_select_info.name_selected_column.size() == 1 && tb_select_info.name_selected_column[0] == "*")
	{
		;
	}
	else
	{
		for (int j = 0; j < tb_select_info.name_selected_column.size(); j++)
		{
			std::string name = tb_select_info.name_selected_column[j];
			if (!table_index_head_info.IsColumnName(name))
				throw SQLError::TABLE_ERROR("Selected fields do not exist!");
		}
	}

	// ����������

	for (int j = 0; j < tb_select_info.vec_cmp_cell.size(); j++)
	{
		auto &cmp = tb_select_info.vec_cmp_cell[j];
		if (!table_index_head_info.IsColumnName(cmp.cmp_value.columu_name))
			throw SQLError::TABLE_ERROR("Where Expr Fields do not exist!");
		if (table_index_head_info.GetColumnType(cmp.cmp_value.columu_name) != cmp.cmp_value.column_type)
			throw SQLError::TABLE_ERROR("Where Expr Fields type error!");
		if (cmp.OperType != Operator_Type::B
			&& cmp.OperType != Operator_Type::BE
			&& cmp.OperType != Operator_Type::E
			&& cmp.OperType != Operator_Type::L
			&& cmp.OperType != Operator_Type::LE
			&& cmp.OperType != Operator_Type::NE)
			throw SQLError::TABLE_ERROR("Where Expr relational operator error!");

	}
}
