create database db;
use database db;
execfile student.txt;
execfile testSql.sql;
quit;