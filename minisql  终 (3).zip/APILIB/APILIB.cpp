#include "APILIB.h"
#include <iterator>
#include <vector>
bool CreateDatabase(std::string db_name, CatalogPosition &cp)
{
	std::string tmp_path = cp.GetRootPath() + db_name;

	if (_access(tmp_path.c_str(), 0) == -1)  //�ж����ݿ��Ƿ����
	{
		tmp_path = cp.GetRootPath() + db_name;
		_mkdir(tmp_path.c_str());
		return true;
	}
	else
	{
		std::cout << "Database has been existed!Create Failed!" << std::endl;
		return false;
	}
}

bool UseDatabase(std::string db_name, CatalogPosition &cp)
{
	// ���ж����ݿ��Ƿ����
	std::string tmp_path = cp.GetRootPath() + db_name;

	if (_access(tmp_path.c_str(), 0) == -1)  //�ж����ݿ��Ƿ����
	{
		return false;
	}
	else
	{
		cp.SetCurrentPath(cp.GetRootPath() + db_name + "/");
		cp.isInSpeDb = true;
		return true;
	}
}

bool CreateTable(TB_Create_Info tb_create_info, std::string path)
{
	// TODO ��鴴����Ϣ�Լ���ǰĿ¼�Ƿ������ݿ���

	Check_TB_Create_Info(tb_create_info);

	if (!GetCp().GetIsInSpeDb())
		return false;

	// ����
	std::string table_name = tb_create_info.table_name;
	std::string idx_file = path + table_name + ".idx";
	std::string dbf_file = path + table_name + ".dbf";

	// �ؼ���λ��,û�����õ������Ĭ��Ϊ��һ���ֶ�
	int KeyTypeIndex = 0;
	for (int j = 0; j < tb_create_info.columns_info.size(); j++)
	{
		if (tb_create_info.columns_info[j].isPrimary)
		{
			KeyTypeIndex = j;
			break;
		}
	}

	// �ֶ���Ϣ
	char RecordTypeInfo[RecordColumnCount*4];          // ��¼�ֶ�������Ϣ
	char *ptype = RecordTypeInfo;
	char RecordColumnName[RecordColumnCount * ColumnNameLength];
	char IndexColumnName[RecordColumnCount * ColumnNameLength];
	char *pname = RecordColumnName;
	char *pindex = IndexColumnName;
	bool mIsUniqueInfo[RecordColumnCount];	//�ֶ��Ƿ�Ψһ
	bool mIsUniqueBuild[RecordColumnCount]; //�ֶ��Ƿ�Ψһ��������
	int num = 0;
	const auto &column_info_ref = tb_create_info.columns_info;
	for (int i = 0; i < column_info_ref.size(); i++)
	{
		// ������Ϣ
		switch (column_info_ref[i].type)
		{
		case Column_Type::I:
			*ptype++ = 'I';
			break;

		case  Column_Type::D:
			*ptype++ = 'D';
			break;

		case Column_Type::C:
			*ptype++ = 'C';
			*ptype++ = column_info_ref[i].length / 100 + '0';
			*ptype++ = (column_info_ref[i].length % 100) / 10 + '0';
			*ptype++ = column_info_ref[i].length % 10 + '0';
		default:
			break;
		}
		// ������Ϣ
		strcpy(pname, column_info_ref[i].name.c_str());
		strcpy(pindex, column_info_ref[i].index.c_str());
		pname += ColumnNameLength;
		pindex += ColumnNameLength;
		// unique ��Ϣ
		mIsUniqueInfo[i] = column_info_ref[i].isUnique == true;
		mIsUniqueBuild[i] = column_info_ref[i].haveIndex;
	}
	*ptype = '\0';
	BPlusTree tree(idx_file, KeyTypeIndex, RecordTypeInfo, RecordColumnName, IndexColumnName,mIsUniqueInfo, KeyTypeIndex, mIsUniqueBuild);
	// ���������ļ�
	for (int i = 0; i < column_info_ref.size(); i++) {
		if (mIsUniqueInfo[i]) {
			if(i!= KeyTypeIndex)
		    {
				std::string unique_file = path + column_info_ref[i].name + ".idx";
				pair<string, int>p1(column_info_ref[i].name, i);
				BPlusTree tree1(unique_file,i, RecordTypeInfo, RecordColumnName, IndexColumnName, mIsUniqueInfo, KeyTypeIndex, mIsUniqueBuild);
			}
		}
	}

	// ���������ļ�
	GetGlobalFileBuffer().CreateFile(dbf_file.c_str());
	return true;
}

bool DropTable(std::string table_name, std::string path)
{
	std::string tmp_path = path + table_name;
	std::string idx = tmp_path + ".idx";
	std::string dbf = tmp_path + ".dbf";
	auto &buffer = GetGlobalFileBuffer();
	auto pClock = GetGlobalPageManager();
	if (!GetCp().GetIsInSpeDb())
		return false;

	if (_access(idx.c_str(), 0) == -1|| _access(dbf.c_str(), 0) == -1)  //�жϱ��Ƿ����
	{
		return false;
	}
	else
	{
		// ����ļ��Ѿ�����ʹ�� ��Ҫ�ȶ������ڴ��е��ļ�ҳ �����������ٴ�д��
		//ɾ�����з���������
		BPlusTree tree(idx);
		TableIndexHeadInfo table_index_head_info(tree);
		IndexHeadNode* phead = tree.GetIdxHeadNodePtr();
		for(int i=0;i<table_index_head_info.GetColumnCount();i++)
			if (phead->UniqueInfo[i] == true&&i!=phead->PrimaryKey)
			{
				string tmp = path + table_index_head_info.GetColumnNames()[i] + ".idx";
				buffer.CloseFile(tmp.c_str());
				remove(tmp.c_str());
			}

		// ɾ�����ļ�
		buffer.CloseFile(idx.c_str());
		buffer.CloseFile(dbf.c_str());
		remove(idx.c_str());
		remove(dbf.c_str());
		return true;
	}

	return false;
}

bool InsertRecord(TB_Insert_Info tb_insert_info, std::string path /*= std::string("./")*/)
{
	if(tb_insert_info.isfull==false)
	Check_TB_Insert_Info(tb_insert_info);  // ������

	std::string idx_file = path + tb_insert_info.table_name + ".idx";
	std::string dbf_file = path + tb_insert_info.table_name + ".dbf";
	BPlusTree tree(idx_file);
	TableIndexHeadInfo table_index_head_info(tree);
	auto phead = tree.GetIdxHeadNodePtr();


	// ����¼��Ϣ��װ�ɼ�¼���ݶ���
	RecordHead record_head;
	int column_id = 0;
	for (int i = 0; phead->RecordTypeInfo[i] != '\0'; i++)
	{
		
		if (phead->RecordTypeInfo[i] == 'I')
		{
			Column_Cell cc;
			//�ҵ���Ӧ���ֶ�����
			char *pColumnName = phead->RecordColumnName + column_id*ColumnNameLength;
			cc.columu_name = pColumnName;
			if (tb_insert_info.isfull) {
				cc.column_type = Column_Type::I;
				cc.column_value.IntValue = stoi(tb_insert_info.insert_info[column_id].column_value);
			}
			else {
				//�ڲ����¼��Ѱ�Ҹ��ֶε�ֵ
				int k = -1;
				for (int j = 0; j < tb_insert_info.insert_info.size(); j++)
				{
					if (pColumnName == tb_insert_info.insert_info[j].column_name)
					{
						k = j;
						break;
					}
				}

				if (k != -1)
				{
					cc.column_type = Column_Type::I;
					cc.column_value.IntValue = stoi(tb_insert_info.insert_info[k].column_value);
				}
				else
				{
					// Ĭ��ֵ���
					cc.column_type = Column_Type::I;
					cc.column_value.IntValue = 0;
				}
			}
			column_id++;
			record_head.AddColumnCell(cc);
		}

		if (phead->RecordTypeInfo[i] == 'D')
		{
			Column_Cell cc;
			//�ҵ���Ӧ���ֶ�����
			char *pColumnName = phead->RecordColumnName + column_id*ColumnNameLength;
			//�ڲ����¼��Ѱ�Ҹ��ֶε�ֵ
			cc.columu_name = pColumnName;
			if (tb_insert_info.isfull) {
				cc.column_type = Column_Type::D;
				cc.column_value.DoubleValue = stod(tb_insert_info.insert_info[column_id].column_value);
			}
			else {
				int k = -1;
				for (int j = 0; j < tb_insert_info.insert_info.size(); j++)
				{
					if (pColumnName == tb_insert_info.insert_info[j].column_name)
					{
						k = j;
						break;
					}
				}

				if (k != -1)
				{
					cc.column_type = Column_Type::D;
					cc.column_value.DoubleValue = stod(tb_insert_info.insert_info[k].column_value);
				}
				else
				{
					// Ĭ��ֵ���
					cc.column_type = Column_Type::D;
					cc.column_value.DoubleValue = 0.0;
				}
			}
			column_id++;
			record_head.AddColumnCell(cc);
		}

		if (phead->RecordTypeInfo[i] == 'C')
		{
			Column_Cell cc;
			//�ҵ���Ӧ���ֶ�����
			char *pColumnName = phead->RecordColumnName + column_id*ColumnNameLength;
			cc.columu_name = pColumnName;
			//�ڲ����¼��Ѱ�Ҹ��ֶε�ֵ
			if (tb_insert_info.isfull) {
				cc.column_type = Column_Type::C;
				cc.sz = table_index_head_info.GetColumnSizeByIndex(column_id);
				char*pChar = (char*)malloc(cc.sz);
				strcpy(pChar, tb_insert_info.insert_info[column_id].column_value.c_str());
				cc.column_value.StrValue = pChar;
			}
			else {
				int k = -1;
				for (int j = 0; j < tb_insert_info.insert_info.size(); j++)
				{
					if (pColumnName == tb_insert_info.insert_info[j].column_name)
					{
						k = j;
						break;
					}
				}

				if (k != -1)
				{
					cc.column_type = Column_Type::C;
					cc.sz = table_index_head_info.GetColumnSizeByIndex(column_id);
					char*pChar = (char*)malloc(cc.sz);
					strcpy(pChar, tb_insert_info.insert_info[k].column_value.c_str());
					cc.column_value.StrValue = pChar;
				}
				else
				{
					// Ĭ��ֵ���
					cc.column_type = Column_Type::C;
					cc.sz = table_index_head_info.GetColumnSizeByIndex(column_id);
					char*pChar = (char*)malloc(cc.sz);
					memset(pChar, 0, cc.sz);
					cc.column_value.StrValue = pChar;
				}
			}
			column_id++;
			record_head.AddColumnCell(cc);
		}

	}


	// ���������ļ�
	Record record;
	auto fd = record.InsertRecord(dbf_file, record_head);

	// ��������
	int key_index = 0;
	auto p_tmp = record_head.GetFirstColumn();
	for (int i = 0; i < column_id; i++) {
		if (i == phead->KeyTypeIndex) {
			 tree.Insert(*p_tmp,fd);
		}
		else {
				if (phead->UniqueInfo[i]) {
					std::string unique_file = path + p_tmp->columu_name + ".idx";
					BPlusTree tree1(unique_file);
					tree1.Insert(*p_tmp,fd);
				}
		
		}
		p_tmp = p_tmp->next;
	}
	return true;
}

SelectPrintInfo SelectTable(TB_Select_Info tb_select_info, std::string path)
{
	Check_TB_Select_Info(tb_select_info);

	std::vector<std::pair<KeyAttr, FileAddr>> res;
	std::vector<std::pair<KeyAttr, FileAddr>> fds;
	GetTimer().Start();
	if (tb_select_info.vec_cmp_cell.empty())  // �������м�¼
	{
		// �����ļ���
		std::string File_IDx = path + tb_select_info.table_name + ".idx";

		// ��ȡ���� ��Ϣ
		BPlusTree tree(File_IDx);
		auto phead = tree.GetIdxHeadNodePtr();

		// ��һ�����ݽ���ַ
		auto node_fd = phead->MostLeftNode;

		while (node_fd.offSet != 0)
		{
			//ȡ������ڼ�¼
			auto pNode = tree.FileAddrToMemPtr(node_fd);
			for (int i = 0; i < pNode->key_totalnum; i++)
			{
				res.push_back({ pNode->key[i], pNode->children[i] });
			}
			// ��һ�����ݽ��
			node_fd = tree.FileAddrToMemPtr(node_fd)->next;
		}
	}
	else
	{
		for (int i = 0; i < tb_select_info.vec_cmp_cell.size(); i++)
		{
			// �������㵥���ֶεļ�¼
			fds = Search(tb_select_info.vec_cmp_cell[i], tb_select_info.table_name, GetCp().GetCurrentPath());
			// �µĽ����֮ǰ�Ľ���󽻼�
			if (res.empty())
			{
				res = fds;
			}
			else
			{
				std::vector<std::pair<KeyAttr, FileAddr>> v;
				sort(fds.begin(), fds.end());
				sort(res.begin(), res.end());
				set_intersection(fds.begin(), fds.end(), res.begin(), res.end(), std::back_inserter(v));
				res = v;
			}

		}
	}
	GetTimer().Stop();
	SelectPrintInfo spi;
	spi.table_name = tb_select_info.table_name;
	spi.name_selected_column = tb_select_info.name_selected_column;
	spi.key_fd = res;
	return spi;
}

bool DeleteTable(TB_Delete_Info tb_delete_info, std::string path /*= std::string("./")*/)
{
	std::string File_IDx = path + tb_delete_info.table_name + ".idx";
	std::string file_dbf = path + tb_delete_info.table_name + ".dbf";

	if (tb_delete_info.deleteall) {
		BPlusTree tree(File_IDx);
		auto phead = tree.GetIdxHeadNodePtr();
		TableIndexHeadInfo table_index_head_info(tree);
		TB_Create_Info tb_create_info;			
		std::vector < std::string > index = table_index_head_info.GetColumnIndex();
		std::vector < std::string > name= table_index_head_info.GetColumnNames();
		std::vector<Column_Type> type = table_index_head_info.GetColumnType();
		for (int i=0; i < table_index_head_info.GetColumnCount(); i++) {
			TB_Create_Info::ColumnInfo column_info;

			column_info.type = type[i];
			column_info.haveIndex = table_index_head_info.IsUniqueBuild(name[i]);
			column_info.isPrimary = table_index_head_info.IsPrimary(name[i]);
			column_info.isUnique= table_index_head_info.IsUnique(name[i]);
			column_info.length = table_index_head_info.GetColumnSizeByIndex(i);
			column_info.name = name[i];
			column_info.index = index[i];
			tb_create_info.columns_info.push_back(column_info);
		}
		tb_create_info.table_name = tb_delete_info.table_name;
		DropTable(tb_delete_info.table_name, path);
		CreateTable(tb_create_info, path);
	}
	else {
		// �����²�����expr������װ�ɲ�������
		std::vector<CompareCell> cmp_cells;
		auto fields_name = GetColumnAndTypeFromTable(tb_delete_info.table_name, GetCp().GetCurrentPath());

		for (int i = 0; i < tb_delete_info.expr.size(); i++)
		{
			CompareCell cmp_cell = CreateCmpCell(tb_delete_info.expr[i].field, GetType(tb_delete_info.expr[i].field, fields_name)
				, GetOperatorType(tb_delete_info.expr[i].op), tb_delete_info.expr[i].value);
			cmp_cells.push_back(cmp_cell);
		}

		// ������������������ֶ�
		std::vector<std::pair<KeyAttr, FileAddr>> res;
		std::vector<std::pair<KeyAttr, FileAddr>> fds;

		for (int i = 0; i < cmp_cells.size(); i++)
		{
			// �������㵥���ֶεļ�¼
			fds = Search(cmp_cells[i], tb_delete_info.table_name, GetCp().GetCurrentPath());
			// �µĽ����֮ǰ�Ľ���󽻼�
			if (res.empty())
			{
				res = fds;
			}
			else
			{
				std::vector<std::pair<KeyAttr, FileAddr>> v;
				sort(fds.begin(), fds.end());
				sort(res.begin(), res.end());
				set_intersection(fds.begin(), fds.end(), res.begin(), res.end(), std::back_inserter(v));
				res = v;
			}
		}

		// ɾ������ɾ���Ľ��
		BPlusTree tree(File_IDx);
		auto phead = tree.GetIdxHeadNodePtr();
		Record record;
		TableIndexHeadInfo table_index_head_info(tree);
		for (int i = 0; i < res.size(); i++)
		{
			RecordHead reas = GetDbfRecord(tb_delete_info.table_name, tree.Delete(res[i].first), path);
			auto preas = reas.GetFirstColumn();
			while (preas) {
				if (table_index_head_info.IsUnique(preas->columu_name))
				{
					std::string unique_file = path + preas->columu_name + ".idx";
					BPlusTree tree1(unique_file);
					tree1.Delete(*preas);
				}
				preas = preas->next;

			}
			record.DeleteRecord(file_dbf, res[i].second, 0);
		}
	}
	return true;
}

bool doIndex(Index_Info index_info, std::string path)
{
	std::string idx_file = path  + index_info.col_name + ".idx";	
	std::string idx = path + index_info.table_name + ".idx";
	BPlusTree tree(idx);	

	auto phead = tree.GetIdxHeadNodePtr();

	TableIndexHeadInfo manager(tree);
	
		if (manager.IsColumnName(index_info.col_name) == false&&index_info.isCreate) {
			throw SQLError::TABLE_ERROR("The Field is not in this table!");
		}
		
		//����/ɾ������
		if (!index_info.isCreate) {

			int index = manager.GetIndexFile(index_info.index_name);
			if (index == -1)
				throw SQLError::TABLE_ERROR("The Field is not in this table!");
			if (tree.GetIdxHeadNodePtr()->IsUniqueBuild[index] && tree.GetIdxHeadNodePtr()->UniqueInfo[index])
			{
				tree.GetIdxHeadNodePtr()->IsUniqueBuild[index] = false;
				cout << "drop index " << index_info.index_name << " succeed! ";
			}
			else if (!tree.GetIdxHeadNodePtr()->IsUniqueBuild[index] && tree.GetIdxHeadNodePtr()->UniqueInfo[index]) {
				throw SQLError::TABLE_ERROR("Index is not bulit!");
			}
			else if (!tree.GetIdxHeadNodePtr()->IsUniqueBuild[index]) {
				throw SQLError::TABLE_ERROR("Field is not unique!");
			}

		}
		else
		{
			int index = manager.GetIndex(index_info.col_name);
			if (!tree.GetIdxHeadNodePtr()->IsUniqueBuild[index] && tree.GetIdxHeadNodePtr()->UniqueInfo[index]) {
				
				char *phead = tree.GetIdxHeadNodePtr()->IndexName+ index * ColumnNameLength;
				strcpy(phead, index_info.index_name.c_str());
				tree.GetIdxHeadNodePtr()->IsUniqueBuild[index] = true;
				cout << "create index " << index_info.index_name << " succeed! ";
			}
			else if (tree.GetIdxHeadNodePtr()->IsUniqueBuild[index] && tree.GetIdxHeadNodePtr()->UniqueInfo[index]) {
				throw SQLError::TABLE_ERROR("Index already existed!");
			}
			else if (!tree.GetIdxHeadNodePtr()->IsUniqueBuild[index]) {
				throw SQLError::TABLE_ERROR("Field is not unique!");

			}
		}
	return true;
}

RecordHead GetDbfRecord(std::string table_name, FileAddr fd, std::string path /*= std::string("./")*/)
{
	std::string idx_file = path + table_name + ".idx";
	std::string dbf_file = path + table_name + ".dbf";
	BPlusTree tree(idx_file);

	RecordHead record_head;
	// ��ȡ����ڴ��ַ
	char* pRecTypeInfo = tree.GetIdxHeadNodePtr()->RecordTypeInfo;
	//std::cout << pRecTypeInfo << std::endl;
	auto pdata = (char*)GetGlobalFileBuffer()[dbf_file.c_str()]->ReadRecord(&fd);
	pdata += sizeof(FileAddr);  // ÿ����¼ͷ��Ĭ�����Ӹü�¼�ĵ�ֵַ

	auto vec_name_type = GetColumnAndTypeFromTable(table_name, path);
	int index = 0;
	while (*pRecTypeInfo != '\0')
	{
		Column_Cell cc;
		switch (*pRecTypeInfo)
		{
		case 'I':
			cc.column_type = Column_Type::I;
			cc.columu_name = vec_name_type[index].first;
			cc.column_value.IntValue = *(int*)pdata;
			pdata += sizeof(int);
			record_head.AddColumnCell(cc);
			index++;
			break;

		case 'D':
			cc.column_type = Column_Type::D;
			cc.columu_name = vec_name_type[index].first;
			cc.column_value.DoubleValue = *(double*)pdata;
			pdata += sizeof(double);
			record_head.AddColumnCell(cc);
			index++;
			break;

		case 'C':
			cc.column_type = Column_Type::C;
			cc.columu_name = vec_name_type[index].first;
			// ��ȡ�ַ�������
			int sz = 0;
			sz = (*(pRecTypeInfo + 1) - '0') * 100 + (*(pRecTypeInfo + 2) - '0') * 10 + (*(pRecTypeInfo + 3) - '0');
			auto pchar = (char*)malloc(sz);
			memcpy(pchar, pdata, sz);
			cc.column_value.StrValue = pchar;
			pdata += sz;
			record_head.AddColumnCell(cc);
			index++;
			break;
		}
		pRecTypeInfo++;
	}

	return record_head;
}

void PrintRecord(std::string table_name, KeyAttr key, FileAddr fd, std::string path /*= std::string("./")*/)
{
	std::string idx_file = path + table_name + ".idx";
	std::string dbf_file = path + table_name + ".dbf";
	BPlusTree tree(idx_file);
	auto tree_head = tree.GetIdxHeadNodePtr();
	// ����ؼ���
	std::cout << key ;
	// �����¼ֵ
	RecordHead rd = GetDbfRecord(table_name, fd, path);
	std::cout << rd << std::endl;
}

std::vector<std::pair<std::string, Column_Type>> GetColumnAndTypeFromTable(std::string table_name, std::string table_path)
{
	std::string idx_file = table_path + table_name + ".idx";
	std::string dbf_file = table_path + table_name + ".dbf";
	BPlusTree tree(idx_file);

	auto phead = tree.GetIdxHeadNodePtr();

	// ��¼�����ֶ�����
	std::vector<Column_Type> tb_types;
	int sz_col = 0;// �ֶθ���
	for (int i = 0; phead->RecordTypeInfo[i] != '\0'; i++)
	{
		if (phead->RecordTypeInfo[i] == 'I')
		{
			tb_types.push_back(Column_Type::I);
			sz_col++;
		}
		else if (phead->RecordTypeInfo[i] == 'D')
		{
			tb_types.push_back(Column_Type::D);
			sz_col++;
		}
		else if (phead->RecordTypeInfo[i] == 'C')
		{
			tb_types.push_back(Column_Type::C);
			sz_col++;
		}

	}

	// ��¼�����ֶ�����
	std::vector<std::string> tb_names;
	char *pColumnName = phead->RecordColumnName;
	for (int j = 0; j < sz_col; j++)
	{
		tb_names.push_back(pColumnName);
		pColumnName += ColumnNameLength;
	}

	std::vector<std::pair<std::string, Column_Type>> res;
	for (int i = 0; i < tb_names.size(); i++)
	{
		res.push_back({ tb_names[i], tb_types[i] });
	}
	return res;
}

Column_Type GetType(std::string name, std::vector<std::pair<std::string, Column_Type>> vec)
{
	for (int i = 0; i < vec.size(); i++)
	{
		if (vec[i].first == name)
		{
			return vec[i].second;
		}
	}

	return Column_Type::I;
}

std::vector<std::pair<KeyAttr, FileAddr>> Search(CompareCell compare_cell, std::string table_name, std::string path /*= std::string("./")*/)
{
	// ������ҽ��
	std::vector<std::pair<KeyAttr, FileAddr>> res;
	// �����ļ���
	std::string File_IDx = path + table_name + ".idx";

	// ������Ϣ
	BPlusTree tree(File_IDx);
	TableIndexHeadInfo table_index_head_info(tree);

	// �жϴ����ҵ��ֶ��Ƿ��������ֶ�

	bool bKeyComumn = false;
	bKeyComumn = table_index_head_info.IsPrimary(compare_cell.cmp_value.columu_name);
	bool tKeyComumn = false;
	tKeyComumn = table_index_head_info.IsUnique(compare_cell.cmp_value.columu_name);

	bool mKeyComumn = false;

	mKeyComumn= table_index_head_info.IsUniqueBuild(compare_cell.cmp_value.columu_name);
	// ����

	if (tKeyComumn)
	{
		
		if (bKeyComumn) { 
			cout << "pkeysearch" << endl;
			res = KeySearch(compare_cell, table_name, path); 
		}
		else if (mKeyComumn) { 
			cout << "ukeysearch" << endl;
			res = KeySearch(compare_cell, compare_cell.cmp_value.columu_name, path); 
		}
		else {
			cout << "rangesearch" << endl;
			res = RangeSearch(compare_cell, table_name, path);
	}
	}
	else
	{
		res = RangeSearch(compare_cell, table_name, path);
	}

	return res;
}

std::vector<std::pair<KeyAttr, FileAddr>> KeySearch(CompareCell compare_cell, std::string table_name, std::string path /*= std::string("./")*/)
{
	// ������ҽ��
	std::vector<std::pair<KeyAttr, FileAddr>> res;
	// �����ļ���
	std::string File_IDx = path + table_name + ".idx";

	// ��ȡ���� ��Ϣ
	BPlusTree tree(File_IDx);
	auto phead = tree.GetIdxHeadNodePtr();

	// ����ǲ�����ȵ�ֵ
	if (compare_cell.OperType == Operator_Type::E)
	{
		FileAddr fd = tree.Search(compare_cell.cmp_value);
		if (fd.offSet!=0)
		{
			res.push_back({ compare_cell.cmp_value , fd });
		}
	}
	else  // ���Ż�::�ؼ��ֶ��ֲ���
	{
		// ��һ�����ݽ���ַ
		auto node_fd = phead->MostLeftNode;

		while (node_fd.offSet != 0)
		{
			//ȡ������ڼ�¼
			const BPlusTNode *pNode = tree.FileAddrToMemPtr(node_fd);
			for (int i = 0; i < pNode->key_totalnum; i++)
			{
				// ���ұȽϵ��ֶ�
				Column_Cell cc(pNode->key[i]);
				bool isSearched = compare_cell(cc);
				if (isSearched)  // ��������
				{
					res.push_back({ pNode->key[i] ,pNode->children[i] });
				}
			}
			// ��һ�����ݽ��
			node_fd = tree.FileAddrToMemPtr(node_fd)->next;
		}
	}

	return res;
}

std::vector<std::pair<KeyAttr, FileAddr>> RangeSearch(CompareCell compare_cell, std::string table_name, std::string path)
{
	// ������ҽ��
	std::vector<std::pair<KeyAttr, FileAddr>> res;
	// �����ļ���
	std::string File_IDx = path + table_name + ".idx";

	// ��ȡ���� ��Ϣ
	BPlusTree tree(File_IDx);
	const auto phead = tree.GetIdxHeadNodePtr();

	// ��һ�����ݽ���ַ
	auto node_fd = phead->MostLeftNode;

	while (node_fd.offSet!=0)
	{
		//ȡ������ڼ�¼
		const  BPlusTNode *pNode = tree.FileAddrToMemPtr(node_fd);

		for (int i = 0; i < pNode->key_totalnum; i++)
		{
			RecordHead record = GetDbfRecord(table_name, pNode->children[i], path);

			// ���ұȽϵ��ֶ�
			const Column_Cell *pColumn = record.GetFirstColumn();
			while (pColumn && pColumn->columu_name != compare_cell.cmp_value.columu_name)pColumn = pColumn->next;
			bool isSearched = compare_cell(*pColumn);
			if (isSearched)  // ��������
			{
				res.push_back({ pNode->key[i] ,pNode->children[i] });
			}

		}

		// ��һ��B+tree���
		node_fd = tree.FileAddrToMemPtr(node_fd)->next;
	}

	return res;
}

